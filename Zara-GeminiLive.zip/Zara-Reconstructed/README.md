# Zara Android Project

A reconstructed Zara-branded Android starter project using Kotlin and Jetpack Compose.

## Upload this project to GitHub

1. Create a new **empty** repository on GitHub (for example, `Zara`).
2. Download and extract `Zara-GitHub-Ready.zip`.
3. Open the extracted `Zara-Reconstructed` folder. You should see `app`, `.github`, `build.gradle.kts`, and `settings.gradle.kts` directly inside it.
4. Upload **the contents of that folder** to the repository root. Do not upload the ZIP itself and do not create an extra nested folder.
5. Commit the files to the `main` branch.
6. Open the repository's **Actions** tab. The `Build Zara APK` workflow starts automatically after the push. You can also select it and press **Run workflow**.
7. When the run succeeds, open the completed workflow run, scroll to **Artifacts**, and download `Zara-debug-apk`.

## Build locally

Open this folder in Android Studio with JDK 17, allow Gradle sync, then run the `app` configuration or execute:

```bash
gradle --no-daemon :app:assembleDebug
```

The GitHub Actions workflow installs Gradle 8.9 and uses the Android SDK available on the GitHub-hosted Ubuntu runner.

## Live voice call (Gemini Live)

1. Install the APK, open **Settings > Connections** and paste your Gemini API key (from Google AI Studio). The key is stored only on the device.
2. Tap the big mic orb on Home (or the centre orb in the bottom bar). Allow the microphone.
3. Talk. Zara answers with voice, you can interrupt her, **Mute** pauses your mic, **Minimize** keeps the call running in the background (foreground service + notification), **End** hangs up.

Transport: Gemini Live WebSocket, mic 16 kHz PCM in, 24 kHz PCM out. Echo cancellation, noise suppression and gain control come from Android's call audio pipeline (the same one WebRTC uses).
The Live model name is editable in Connections because Google renames preview models often.

## Project status

Chat replies are still placeholders; image creation, voice rooms and phone control are not implemented. Debug APK only, not Play Store signed.
