package com.zara.ai

import android.content.Context

object Prefs {
    const val DEFAULT_MODEL = "gemini-3.1-flash-live-preview"
    const val DEFAULT_VOICE = "Aoede"

    private fun sp(c: Context) = c.getSharedPreferences("zara", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("gemini_key", "")?.trim().orEmpty()
    fun model(c: Context): String = sp(c).getString("model", DEFAULT_MODEL)?.trim().orEmpty().ifBlank { DEFAULT_MODEL }
    fun voice(c: Context): String = sp(c).getString("voice", DEFAULT_VOICE)?.trim().orEmpty().ifBlank { DEFAULT_VOICE }

    fun save(c: Context, key: String, model: String, voice: String) {
        sp(c).edit().putString("gemini_key", key.trim()).putString("model", model.trim()).putString("voice", voice.trim()).apply()
    }
}
