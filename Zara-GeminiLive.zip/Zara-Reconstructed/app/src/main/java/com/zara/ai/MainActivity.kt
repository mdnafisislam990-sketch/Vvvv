package com.zara.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.core.content.ContextCompat
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*

private val Night = Color(0xFF050511)
private val Card = Color(0xFF111027)
private val Purple = Color(0xFF9C4DFF)
private val Lavender = Color(0xFFC5A5FF)
private val Soft = Color(0xFF9994B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5, 5, 17)
        window.navigationBarColor = android.graphics.Color.rgb(5, 5, 17)
        setContent { ZaraApp() }
    }
}

@Composable
fun ZaraApp() {
    var tab by remember { mutableStateOf("Home") }
    var prompt by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    val callState by LiveSession.state.collectAsState()
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
        if (granted[Manifest.permission.RECORD_AUDIO] == true) { beginCall(ctx); tab = "Call" }
        else Toast.makeText(ctx, "Microphone permission is needed to talk with Zara", Toast.LENGTH_LONG).show()
    }
    val startCall: () -> Unit = {
        when {
            callState != CallState.IDLE && callState != CallState.ERROR -> tab = "Call"
            Prefs.apiKey(ctx).isBlank() -> { Toast.makeText(ctx, "Add your Gemini API key in Settings > Connections", Toast.LENGTH_LONG).show(); tab = "Settings" }
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED -> { beginCall(ctx); tab = "Call" }
            else -> micLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS))
        }
    }
    var messages by remember { mutableStateOf(listOf<Pair<Boolean, String>>()) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Night, surface = Card)) {
        Box(Modifier.fillMaxSize().background(Night)) {
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                when (tab) {
                    "Chat" -> ChatPage(messages, prompt, { prompt = it }, { value ->
                        if (value.isNotBlank()) { messages = messages + (true to value) + (false to "Hi! I'm Zara. Connect your AI provider in Settings to enable live answers."); prompt = "" }
                    }, { tab = "Home" })
                    "Call" -> CallScreen(onMinimize = { tab = "Home" }, onEnd = { endCall(ctx); tab = "Home" })
                    "Settings" -> SettingsPage { tab = "Home" }
                    "History" -> HistoryPage { tab = "Chat" }
                    "Create Image" -> SimplePage("Create Image", "Turn your ideas into beautiful images", "Image creation provider can be connected in Settings.") { tab = "Home" }
                    "Write" -> SimplePage("Write with Zara", "Notes, code and content", "Start with a prompt in Chat to create something.") { tab = "Chat" }
                    else -> HomePage(prompt, { prompt = it }, { value ->
                        if (value.isNotBlank()) { messages = messages + (true to value) + (false to "Hi! I'm Zara. Connect your AI provider in Settings to enable live answers."); prompt = ""; tab = "Chat" }
                    }, callState != CallState.IDLE && callState != CallState.ERROR, { startCall() }, { tab = it })
                }
                }
                if (tab != "Call") BottomBar(tab, { tab = it }, { startCall() })
            }
        }
    }
}

@Composable
private fun Header(onMenu: () -> Unit, onSettings: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        RoundIcon(Icons.Default.Menu, onMenu)
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("ZARA", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text(" AI", color = Purple, fontSize = 29.sp, fontWeight = FontWeight.Black)
            }
            Text("Y O U R   A I   A S S I S T A N T", color = Soft, fontSize = 8.sp, letterSpacing = 1.sp)
        }
        Spacer(Modifier.weight(1f))
        RoundIcon(Icons.Default.Settings, onSettings)
    }
}

@Composable
private fun RoundIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, click: () -> Unit) {
    Box(Modifier.size(48.dp).clip(RoundedCornerShape(17.dp)).background(Color(0xFF17162D)).border(1.dp, Color(0xFF30284A), RoundedCornerShape(17.dp)).clickable { click() }, contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = Color(0xFFE8E2FF), modifier = Modifier.size(23.dp))
    }
}

@Composable
private fun HomePage(prompt: String, onPrompt: (String) -> Unit, send: (String) -> Unit, listening: Boolean, onVoice: () -> Unit, navigate: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header(onMenu = { navigate("History") }, onSettings = { navigate("Settings") })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.fillMaxWidth().height(435.dp)) {
                Image(painterResource(R.drawable.zara_hero), contentDescription = "Zara assistant portrait", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Night.copy(alpha = .12f), Color.Transparent, Night.copy(alpha = .78f)))))
                Column(Modifier.align(Alignment.TopStart).padding(start = 28.dp, top = 35.dp)) {
                    Text("Hi,", color = Color(0xFFFFC9FF), fontSize = 25.sp, fontWeight = FontWeight.Light)
                    Text("I'm", color = Color(0xFFFFC9FF), fontSize = 25.sp, fontWeight = FontWeight.Light)
                    Text("ZARA", color = Color(0xFFFFC9FF), fontSize = 32.sp, fontWeight = FontWeight.Light)
                    Text("♡", color = Color(0xFFFFC9FF), fontSize = 24.sp)
                }
                Column(Modifier.align(Alignment.TopEnd).padding(end = 24.dp, top = 48.dp), horizontalAlignment = Alignment.End) {
                    Text("Always", color = Lavender, fontSize = 19.sp)
                    Text("Here For", color = Lavender, fontSize = 19.sp)
                    Text("You ♡", color = Lavender, fontSize = 19.sp)
                }
                Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 0.dp).size(190.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFF5522A6), Color(0xCC170D37), Color.Transparent))).border(5.dp, Brush.sweepGradient(listOf(Purple, Color(0xFFFF83D7), Color(0xFF8DABFF), Purple)), CircleShape).clickable { onVoice() }, contentAlignment = Alignment.Center) {
                    Box(Modifier.size(158.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFF241747), Color(0xFF0C0A20)))).border(2.dp, Color(0xFF47316D), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Mic, null, tint = Lavender, modifier = Modifier.size(48.dp))
                    }
                }
            }
            Text(if (listening) "Zara is on call - tap to open" else "Tap to Talk", color = Color(0xFFF0E9FF), fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 2.dp))
            Text("•  •  •  ┃  •  •  •  ┃  •  •  •", color = Purple, fontSize = 15.sp, modifier = Modifier.padding(top = 8.dp, bottom = 18.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp).height(66.dp).clip(RoundedCornerShape(32.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF17152F), Color(0xFF0F0E22)))).border(1.dp, Color(0xFF4B2C76), RoundedCornerShape(32.dp)).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).clip(CircleShape).background(Color(0xFF2A1A4D)), contentAlignment = Alignment.Center) { Icon(Icons.Default.AutoAwesome, null, tint = Purple) }
                BasicTextField(value = prompt, onValueChange = onPrompt, modifier = Modifier.weight(1f).padding(horizontal = 14.dp), textStyle = TextStyle(color = Color.White, fontSize = 16.sp), cursorBrush = Brush.verticalGradient(listOf(Purple, Lavender)), decorationBox = { inner -> if (prompt.isEmpty()) Text("Ask me anything...", color = Soft, fontSize = 16.sp); inner() })
                Box(Modifier.size(48.dp).clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(Color(0xFF9B4EFF), Color(0xFF6332D8)))).clickable { send(prompt) }, contentAlignment = Alignment.Center) { Icon(Icons.Default.Send, null, tint = Color.White) }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard("Chat", "Get instant answers", Icons.Default.ChatBubbleOutline, Modifier.weight(1f)) { navigate("Chat") }
                ActionCard("Create Image", "Photos into sketches", Icons.Default.Image, Modifier.weight(1f)) { navigate("Create Image") }
                ActionCard("Write", "Notes, code, content", Icons.Default.Description, Modifier.weight(1f)) { navigate("Write") }
            }
        }
    }
}

@Composable
private fun ActionCard(title: String, sub: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, click: () -> Unit) {
    Column(modifier.height(150.dp).clip(RoundedCornerShape(25.dp)).background(Brush.verticalGradient(listOf(Color(0xFF17152F), Color(0xFF0D0D1D)))).border(1.dp, Color(0xFF35234F), RoundedCornerShape(25.dp)).clickable { click() }.padding(horizontal = 7.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(55.dp).clip(CircleShape).background(Color(0xFF292149)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Lavender, modifier = Modifier.size(26.dp)) }
        Spacer(Modifier.height(9.dp)); Text(title, color = Color(0xFFF0EDFF), fontSize = 14.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center); Text(sub, color = Soft, fontSize = 10.sp, lineHeight = 13.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun BottomBar(tab: String, navigate: (String) -> Unit, onOrb: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 8.dp).height(82.dp).clip(RoundedCornerShape(42.dp)).background(Brush.verticalGradient(listOf(Color(0xFF27204C), Color(0xFF17142E)))).border(1.dp, Color(0xFF39305E), RoundedCornerShape(42.dp)).padding(horizontal = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceAround) {
        BottomItem("Home", Icons.Default.Home, tab == "Home") { navigate("Home") }
        BottomItem("Chat", Icons.Default.Chat, tab == "Chat") { navigate("Chat") }
        Box(Modifier.size(66.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFFB07AFF), Color(0xFF5525B5), Color(0xFF24133F)))).border(2.dp, Color(0xFFFFC66D), CircleShape).clickable { onOrb() }, contentAlignment = Alignment.Center) {
            Box(Modifier.size(48.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFFB98AFF), Color(0xFF5424B4), Color(0xFF201039)))))
        }
        BottomItem("History", Icons.Default.History, tab == "History") { navigate("History") }
        BottomItem("Settings", Icons.Default.Settings, tab == "Settings") { navigate("Settings") }
    }
}

@Composable
private fun BottomItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, click: () -> Unit) {
    Column(Modifier.clickable { click() }.width(58.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = if (selected) Color(0xFFFFB83D) else Color(0xFF9690B4), modifier = Modifier.size(23.dp))
        Text(label, color = if (selected) Color(0xFFFFB83D) else Color(0xFF9690B4), fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))
        if (selected) Box(Modifier.padding(top = 3.dp).width(22.dp).height(3.dp).clip(CircleShape).background(Color(0xFFFFB83D)))
    }
}

@Composable
private fun ChatPage(messages: List<Pair<Boolean, String>>, prompt: String, onPrompt: (String) -> Unit, send: (String) -> Unit, back: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.ArrowBack, null, tint = Color.White, modifier = Modifier.clickable { back() }); Spacer(Modifier.width(14.dp)); Column { Text("Zara AI", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold); Text("Your personal assistant", color = Soft, fontSize = 11.sp) } }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
            if (messages.isEmpty()) item { Text("Hello! I'm Zara. How can I help you today?", color = Color.White, modifier = Modifier.fillMaxWidth().padding(top = 80.dp), textAlign = TextAlign.Center) }
            items(messages) { (user, message) -> Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) { Text(message, color = Color.White, modifier = Modifier.widthIn(max = 290.dp).clip(RoundedCornerShape(18.dp)).background(if (user) Color(0xFF4D287E) else Card).padding(14.dp), fontSize = 14.sp) } }
        }
        ChatInput(prompt, onPrompt, send)
    }
}

@Composable
private fun ChatInput(prompt: String, onPrompt: (String) -> Unit, send: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp).clip(RoundedCornerShape(28.dp)).background(Card).border(1.dp, Color(0xFF43305F), RoundedCornerShape(28.dp)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        BasicTextField(prompt, onPrompt, Modifier.weight(1f).padding(12.dp), textStyle = TextStyle(color = Color.White, fontSize = 14.sp), decorationBox = { inner -> if (prompt.isEmpty()) Text("Message Zara...", color = Soft); inner() })
        IconButton(onClick = { send(prompt) }) { Icon(Icons.Default.Send, null, tint = Lavender) }
    }
}

@Composable
private fun SettingsPage(back: () -> Unit) {
    var showConn by remember { mutableStateOf(false) }
    if (showConn) ConnectionsDialog { showConn = false }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.ArrowBack, null, tint = Color.White, modifier = Modifier.clickable { back() }); Spacer(Modifier.width(14.dp)); Text("ZARA AI Settings", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold) }
        Text("Customize your AI experience", color = Soft, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp, bottom = 18.dp))
        SettingGroup("AI SETTINGS", listOf("Connections" to "Gemini and Groq keys", "Voice & language" to "Voice • Auto • 10x", "Chats & memory" to "Manage your saved chats"), onClick = { if (it == "Connections") showConn = true })
        SettingGroup("APP SETTINGS", listOf("Look & feel" to "Dark • Classic orb", "Voice keyboard" to "Push to type • English", "Broadcast & Voice Rooms" to "Create rooms and talk", "Phone control" to "Call, contacts and permissions"))
        SettingGroup("ABOUT", listOf("Privacy & about" to "Your privacy matters", "About Zara" to "Your personal AI assistant"))
        Text("Tap Connections and paste your Gemini API key to enable live voice calls.", color = Soft, fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.padding(8.dp))
    }
}

@Composable
private fun SettingGroup(title: String, rows: List<Pair<String, String>>, onClick: (String) -> Unit = {}) {
    Text(title, color = Lavender, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 14.dp, bottom = 8.dp))
    rows.forEach { (name, detail) -> Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(16.dp)).background(Card).border(1.dp, Color(0xFF292342), RoundedCornerShape(16.dp)).clickable { onClick(name) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF30204D)), contentAlignment = Alignment.Center) { Icon(Icons.Default.AutoAwesome, null, tint = Lavender, modifier = Modifier.size(18.dp)) }
        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold); Text(detail, color = Soft, fontSize = 11.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Soft)
    } }
}

@Composable
private fun HistoryPage(openChat: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Text("History", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("Your recent conversations", color = Soft, fontSize = 12.sp)
        Spacer(Modifier.height(22.dp)); Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Card).clickable { openChat() }.padding(25.dp), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.History, null, tint = Lavender, modifier = Modifier.size(34.dp)); Text("No saved chats yet", color = Color.White, fontWeight = FontWeight.SemiBold); Text("Start a conversation with Zara", color = Soft, fontSize = 11.sp) } }
    }
}

@Composable
private fun SimplePage(title: String, subtitle: String, detail: String, back: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.ArrowBack, null, tint = Color.White, modifier = Modifier.clickable { back() }); Spacer(Modifier.width(12.dp)); Text(title, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold) }
        Text(subtitle, color = Soft, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)); Spacer(Modifier.height(24.dp))
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Card).padding(24.dp), contentAlignment = Alignment.Center) { Text(detail, color = Soft, textAlign = TextAlign.Center) }
    }
}


@Composable
private fun ConnectionsDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(Prefs.apiKey(ctx)) }
    var model by remember { mutableStateOf(Prefs.model(ctx)) }
    var voice by remember { mutableStateOf(Prefs.voice(ctx)) }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Card,
        title = { Text("Gemini Live", color = Color.White) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(key, { key = it }, label = { Text("Gemini API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(model, { model = it }, label = { Text("Live model") }, singleLine = true)
                OutlinedTextField(voice, { voice = it }, label = { Text("Voice (e.g. Aoede, Puck, Kore)") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { Prefs.save(ctx, key, model, voice); onClose() }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}
