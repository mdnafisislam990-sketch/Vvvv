package com.zara.ai

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val CallSoft = Color(0xFF9994B8)

@Composable
fun CallScreen(onMinimize: () -> Unit, onEnd: () -> Unit) {
    val state by LiveSession.state.collectAsState()
    val level by LiveSession.level.collectAsState()
    val muted by LiveSession.muted.collectAsState()
    val error by LiveSession.error.collectAsState()
    BackHandler { onMinimize() }

    val status = when {
        state == CallState.ERROR -> error ?: "Something went wrong"
        state == CallState.CONNECTING -> "Connecting..."
        muted -> "You're muted"
        state == CallState.SPEAKING -> "Zara is speaking..."
        state == CallState.THINKING -> "Zara is thinking..."
        else -> "Zara is listening..."
    }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF080620), Color(0xFF0A0722), Color(0xFF040410)))
        )
    ) {
        Column(Modifier.fillMaxSize().navigationBarsPadding().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth().padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Zara", color = Color(0xFFEDE8FF), fontSize = 24.sp, fontFamily = FontFamily.Serif)
                Spacer(Modifier.weight(1f))
                Box(
                    Modifier.size(38.dp).clip(CircleShape).background(Color(0xFF17162D)).clickable { onMinimize() },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.KeyboardArrowDown, null, tint = Color(0xFFE8E2FF)) }
            }
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Orb(state, level) }
            Text(
                status, color = Color(0xFFF0E9FF), fontSize = 26.sp, fontStyle = FontStyle.Italic,
                fontFamily = FontFamily.Serif, textAlign = TextAlign.Center
            )
            Text(
                "Keeps listening if you leave this screen.", color = CallSoft, fontSize = 12.sp,
                modifier = Modifier.padding(top = 10.dp, bottom = 34.dp)
            )
            Row(Modifier.fillMaxWidth().padding(bottom = 26.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                CallButton(if (muted) Icons.Default.MicOff else Icons.Default.Mic, "Mute", Color(0xFF1B1840), 58) { LiveSession.toggleMute() }
                CallButton(Icons.Default.CallEnd, "End", Color(0xFFF0626A), 70) { onEnd() }
                CallButton(Icons.Default.KeyboardArrowDown, "Minimize", Color(0xFF1B1840), 58) { onMinimize() }
            }
        }
    }
}

@Composable
private fun CallButton(icon: ImageVector, label: String, bg: Color, size: Int, click: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(size.dp).clip(CircleShape).background(bg).border(1.dp, Color(0x33FFFFFF), CircleShape).clickable { click() },
            contentAlignment = Alignment.Center
        ) { Icon(icon, label, tint = Color.White, modifier = Modifier.size(26.dp)) }
        Spacer(Modifier.height(6.dp))
        Text(label, color = CallSoft, fontSize = 12.sp)
    }
}

/** Animated orb: orange/violet while speaking, teal while listening, pale blue while thinking. */
@Composable
private fun Orb(state: CallState, level: Float) {
    val tint = when (state) {
        CallState.SPEAKING -> Triple(Color(0xFFFF9A3D), Color(0xFF7B3DFF), Color(0xFFFF5FA8))
        CallState.THINKING -> Triple(Color(0xFF9DB4FF), Color(0xFF4A55B8), Color(0xFFD0D8F5))
        CallState.ERROR -> Triple(Color(0xFFFF6A6A), Color(0xFF5A1F2E), Color(0xFFB04A5A))
        else -> Triple(Color(0xFF2EE6D6), Color(0xFF14607E), Color(0xFF6FD6B8))
    }
    val c1 by animateColorAsState(tint.first, tween(700), label = "c1")
    val c2 by animateColorAsState(tint.second, tween(700), label = "c2")
    val c3 by animateColorAsState(tint.third, tween(700), label = "c3")
    val lvl by animateFloatAsState(level.coerceIn(0f, 1f), tween(120), label = "lvl")

    val inf = rememberInfiniteTransition(label = "orb")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(16000, easing = LinearEasing)), label = "spin")
    val spin2 by inf.animateFloat(360f, 0f, infiniteRepeatable(tween(23000, easing = LinearEasing)), label = "spin2")
    val breathe by inf.animateFloat(0.96f, 1.04f, infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breathe")

    Canvas(Modifier.size(320.dp)) {
        val ctr = center
        val r = size.minDimension / 2f * 0.62f * breathe * (1f + lvl * 0.14f)
        drawCircle(
            brush = Brush.radialGradient(listOf(c1.copy(alpha = 0.50f), Color.Transparent), center = ctr, radius = r * 1.65f),
            radius = r * 1.65f, center = ctr
        )
        clipPath(Path().apply { addOval(Rect(ctr, r)) }) {
            drawRect(Brush.radialGradient(listOf(c2, Color(0xFF060A18)), center = ctr, radius = r * 1.1f))
            rotate(spin, ctr) {
                val a = ctr + Offset(r * 0.38f, -r * 0.28f)
                drawCircle(brush = Brush.radialGradient(listOf(c1.copy(alpha = 0.95f), Color.Transparent), center = a, radius = r * 0.75f), radius = r * 0.75f, center = a)
            }
            rotate(spin2, ctr) {
                val b = ctr + Offset(-r * 0.42f, r * 0.30f)
                drawCircle(brush = Brush.radialGradient(listOf(c3.copy(alpha = 0.85f), Color.Transparent), center = b, radius = r * 0.7f), radius = r * 0.7f, center = b)
            }
            val h = ctr + Offset(-r * 0.3f, -r * 0.45f)
            drawCircle(brush = Brush.radialGradient(listOf(Color.White.copy(alpha = 0.28f), Color.Transparent), center = h, radius = r * 0.5f), radius = r * 0.5f, center = h)
        }
        drawCircle(color = c1.copy(alpha = 0.55f), radius = r, center = ctr, style = Stroke(width = 3f))
    }
}
